#A coin is tossed 10 times, what is the probability:

#a. exactly 4 heads
dbinom(4, 10, 0.5)

#b. at most 4 heads
# use lower.tail 
pbinom(4, 10, 0.5, lower.tail = TRUE)

#c. atleast 4 heads
pbinom(3, 10, 0.5, lower.tail = FALSE)

#d. if probability is 0.45, how many heads?
qbinom(0.45, 10, 0.5)  
