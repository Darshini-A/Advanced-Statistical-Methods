success <- 0:20

plot(success, dbinom(success, size = 20, prob = 0.3), type = 'h')

plot(success, dbinom(success, size = 20, prob = 0.3), type = 'b')

plot(success, dbinom(success, size = 20, prob = 0.3), type = 'p')

plot(success, dbinom(success, size = 20, prob = 0.3), type = 's')

plot(success, dbinom(success, size = 20, prob = 0.3), type = 'l')

plot(success, dbinom(success, size = 20, prob = 0.3))

plot(success, dbinom(success, size = 20, prob = 0.3), 
type = 'h',
main = "Binomial distribution (n = 20, p = 0.3)",
ylab = 'Probability',
xlab = 'Success',
lwd = 3)
